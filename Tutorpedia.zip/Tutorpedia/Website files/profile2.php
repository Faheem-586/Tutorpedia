<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php include_once('links.php') ?>


</head>

<body>
  <!-- Header Section End -->
  <?php include_once('header.php') ?>
  <!-- Page Header Start -->


  <br>


  <?php

  include_once("DBConnection.php");
  date_default_timezone_set("Asia/Karachi");
  $conn = new DBCon();

  // Check connection
  if ($conn->Open()) {

    $id = null;

    if (isset($_GET['id']))
      $id = $_GET['id'];

    //$row = null;

    $sql =  "select * from job_info where id='$id'";
    $result = $conn->db->query($sql);

    $row = mysqli_fetch_array($result);

  ?>

    <!-- Main container Start -->
    <div class="main-container">
      <div class="container">
        <div class="row">
          <div class="col-sm-8">

            <div class="frow add_tutor_bg">
              <div class="add_info">About Institute (Job site)</div>
              <br>
              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="name">Institute Name:</label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts"><?php echo $row['name']; ?></span><br><br>
              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b">Institute Locations:</label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts"><?php echo $row['location']; ?>, <?php echo $row['city']; ?></span><br><br>
                </h5>
              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="phone">Phone:</label>
              </div>
              <div class="fcol-75-b">
                <a class="right_texts" href="tel:<?php echo $row['phone']; ?>"><?php echo $row['phone']; ?> (Click to call)</a><br><br>

              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="email">Email:</label>
              </div>
              <div class="fcol-75-b">
                <a class="right_texts" href="mailto:<?php echo $row['email']; ?>"><?php echo $row['email']; ?> </a><br><br>
              </div>

            </div>

            <br>
            <div class="frow add_tutor_bg">
              <div class="add_info">Job Requirements</div><br>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="age">Age:</label>

              </div>

              <div class="fcol-75-b">
                <span class="right_texts"><?php echo $row['age']; ?><br><br>
              </div>



              <div class="fcol-35-b">
                <label class="add_tutor_label_b">Gender: </label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts"><?php echo $row['gender']; ?></span><br><br>
              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="qualification">Minimum Qualification:</label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts"><?php echo $row['qualification']; ?></span><br><br>
              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="teaching_exp">Minimum Experiance:</label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts"><?php echo $row['experiance']; ?><span class="years"> years of teaching experiance</span></span><br><br>
              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b">Grade(s):</label>
              </div>

              <div class="fcol-75-b">
                <div class="fcol-subtitles">
                  <small>This job is for the following grade(s); </small>
                </div>
                <span class="right_texts"> <?php echo $row['grade']; ?></span><br>

              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b">Subject(s):</label>
              </div>

              <div class="fcol-75-b">
                <div class="fcol-subtitles">
                  <small>This job is for the following subject(s); </small>
                </div>

                <span class="right_texts"><?php echo $row['subject']; ?></span><br>

              </div>
              <?php
              $str1 = $row['sal'];
              $str2 = substr($str1, 3);
              ?>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="teaching_exp">Monthly Salary:</label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts"><?php echo $str2; ?><span class="years"> pkrs</span></span><br><br>
              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="teaching_exp">Number of classes:</label>
              </div>
              <div class="fcol-75-b">
                <div class="fcol-subtitles">
                  <small>Number of classes the tutor have to attend: </small>
                </div>
                <span class="right_texts"><?php echo $row['classes']; ?><span class="years"> classes</span></span><br><br>
              </div>
              <div class="fcol-35-b">
                <label class="add_tutor_label_b">Language(s):</label>
              </div>

              <div class="fcol-75-b">
                <div class="fcol-subtitles">
                  <small>Language(s) in which the tutor have to teach: </small>
                </div>

                <span class="right_texts"><?php echo $row['lang']; ?></span><br><br>

              </div>
            </div>
            <br>



            <br>


          </div>

        <?php
        $conn = null;
      }
        ?>

        <div class="card-adds">



          <!-- Addvertisments -->
          <?php include_once('add_2.php') ?>


        </div>


        </div>
      </div>
    </div>
    <!-- Main container End -->


    <!-- Footer Section Start -->
    <?php include_once('footer.php') ?>
    <!-- Footer Section End -->


</body>

</html>