<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php include_once('links.php') ?>


</head>

<body>
  <!-- Header Section End -->
  <?php include_once('header.php') ?>
  <!-- Page Header Start -->


  <!-- Page Header Start -->
  <div class="header-name">

    Tutor Profile

  </div>
  <!-- Page Header End -->
  <br>


  <?php


  include_once("DBConnection.php");
  date_default_timezone_set("Asia/Karachi");
  $conn = new DBCon();

  // Check connection
  if ($conn->Open()) {

    $id = null;

    if (isset($_GET['id']))
      $id = $_GET['id'];

    //$row = null;

    $sql =  "select * from tutor_info where id='$id'";
    $result = $conn->db->query($sql);

    $row = mysqli_fetch_array($result);

  ?>

    <!-- Main container Start -->
    <div class="main-container">
      <div class="container">
        <div class="row">
          <div class="col-sm-8">


            <h2 class="tutor_name"><?php echo $row['name']; ?></h2>


            <div class="card_pic">
              <img class="pic_container" src="<?php echo $row['img']; ?>" alt="<?php echo $row['name']; ?>" width="200" height="270">
            </div>



            <div class="card_buttons">

              <a class="call_button" href="tel:<?php echo $row['phone']; ?>">Call</a>
              <a class="call_button" href="sms:<?php echo $row['phone']; ?>">Text</a>
              <a class="call_button" href="mailto:<?php echo $row['email']; ?>">Email</a>

              <div class="card_age">
                <h5 class="tutor_info">Age: &nbsp; <span class="right_texts"> <?php echo $row['age']; ?><span class="years"> years</span></span></h5>
              </div>

              <div class="card_gender">
                <h5 class="tutor_info">Gender:&nbsp; <span class="right_texts"> <?php echo $row['gender']; ?></span></h5>
              </div>

            </div>

            <?php
            $str1 = $row['price'];
            $str2 = substr($str1, 3);
            ?>


            <div class="card_a">
              <h5 class="tutor_info">Fee per Subject:<br><small>This tutor can teach to students with in the following price range; </small> <br><span class="right_texts"><?php echo $str2; ?></span></h5>
            </div>

            <div class="card_a">
              <h5 class="tutor_info">Teaching Experience: <br> <span class="right_texts"><?php echo $row['teaching_exp']; ?><span class="years"> years</span></span></h5>
            </div>


            <div class="card_b">
              <h5 class="tutor_info">Qualifications:&nbsp; <span class="right_texts"><?php echo $row['qualification']; ?></span></h5>
            </div>

            <div class="card_b">
              <h5 class="tutor_info">Languages: <br><small>This tutor can speak the following language(s); </small><br><span class="right_texts"><?php echo $row['languages']; ?></span></h5>
            </div>

            <div class="card_b">
              <h5 class="tutor_info">Location:<br><small>This tutor can teach to students with in the following location; </small> <br><span class="right_texts"><?php echo $row['city']; ?>, <?php echo $row['province']; ?></span></h5>
            </div>

            <div class="card_c">
              <h5 class="tutor_info">Grade(s):<br><small>This tutor can teach to the following Grade(s); </small><br> <span class="right_texts"> <?php echo $row['grades']; ?></span></h5>
            </div>


            <div class="card_c">
              <h5 class="tutor_info">Subject(s):<br><small>This tutor can teach the following Subject(s); </small><br> <span class="right_texts"><?php echo $row['subjects']; ?></span></h5>
            </div>



          </div>

        <?php
        $conn->db->close();
      }
        ?>

        <div class="card-adds">


          <!-- Addvertisments -->
          <?php include_once('add_2.php') ?>


        </div>


        </div>
      </div>
    </div>
    <!-- Main container End -->


    <!-- Footer Section Start -->
    <?php include_once('footer.php') ?>
    <!-- Footer Section End -->


</body>

</html>