<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php include_once('links.php') ?>

  <title>Tutorpedia | About us</title>

</head>

<body>

  <!-- Header -->
  <?php include_once('header.php') ?>


  <!-- Page Header Start -->
  <div class="header-name">

    About us

  </div>
  <!-- Page Header End -->
  <br>


  <!-- Main container Start -->
  <div class="main-container">
    <div class="container">
      <div class="row">
        <div class="col-sm-8">
          <div class="row">


            <div class="founder_container">


              <div class="founder_info">
                Welcome to<br>
                <h3> Tutorpedia<br></h3><br>
                The best source for finding your tutors/instructors/mentors online all over Pakistan.<br><br>
                Founded in 2015 by Qaisar Afridi,
                Tutorpedia has come a long way from its beginnings in Peshawar, Pakistan.

                When Qaisar Afridi first started out, his passion for finding an easy and accessible way to find out what tutor people need,
                it drove him to build a website, Tutorpedia.
                So that Tutorpedia can find you tutors almost all over Pakistan.
                <br><br>
                We hope you enjoy our service as much as we enjoy offering them to you.
                If you have any questions or comments, please don't hesitate to contact us.
                <br><br><br>
                Founder,<br>
                <a href="https://www.facebook.com/jinnydotshaa"> Qaisar Afridi</a>
              </div>


            </div>


          </div>
        </div><!-- col-sm-8 -->

        <!-- Advertisement -->
        <?php include_once('add_2.php') ?>

      </div>
    </div>
  </div>
  <!-- Main container End -->



  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>