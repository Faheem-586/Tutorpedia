<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>


  <!-- Links -->
  <?php require_once('links.php') ?>

  <title>Tutorpedia | Search Result</title>

</head>

<body>
  <!-- Header Section End -->
  <?php include_once('header.php') ?>
  <!-- Page Header Start -->

  <!-- Page Header Start -->
  <div class="header-name">

    Search Results

  </div>
  <!-- Page Header End -->

  <!-- Main container Start -->
  <div style="padding-left:70px; padding-right:70px" class="main-container">
    <div class="row">
      <div class="ad-detail-content ">

        <?php
        $where = " 1=1";
        $flag = "0";

        if ($_POST["PROVINCE"] <> '')
          $where .= " and location like '%" . $_POST["CITY"] . "%'";
        elseif ($_POST["GRADE"] <> '')
          $where .= " and city like '%" . $_POST["PROVINCE"] . "%'";
        elseif ($_POST["CITY"] <> '')
          $where .= " and grade like '%" . $_POST["GRADE"] . "%'";
        elseif ($_POST["SUBJECT"] <> '')
          $where .= " and subject like '%" . $_POST["SUBJECT"] . "%'";
        elseif ($_POST["SALARY"] <> '')
          $where .= " and sal like '%" . $_POST["SALARY"] . "%'";
        elseif ($_POST["GENDER"] <> '')
          $where .= " and gender like '" . $_POST["GENDER"] . "'";
        else {
          $flag = "1";
        }

        // Create connection
        include_once("DBConnection.php");
        date_default_timezone_set("Asia/Karachi");
        $conn = new DBCon();

        if ($flag == "0") {
          if ($conn->Open()) {
            $sql = " SELECT * FROM job_info WHERE " . $where;
            //  echo $sql;
            $result = $conn->db->query($sql);
            //echo $result;
            if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                $str1 = $row['sal'];
                $str2 = substr($str1, 3);

                echo ' 
                <div class="card_2">
                         <div class="card_2_a">
                
                                <div class="card_2_textbox">
                                
                                        <div class="card_2_h"> <b class="card_2_titles"> Job location/Institute: </b> <br>' . $row["name"] . ' </div> 
                                          <div class="card_2_h"> <b class="card_2_titles"> This job is for:  </b>  &nbsp;' . $row["gender"] . ' </div>
                                          <div class="card_2_h"> <b class="card_2_titles"> Salary:   </b> &nbsp;' . $str2 . ' pkrs </div>
                                          <div class="card_2_h"> <b class="card_2_titles"> Contact:   </b> &nbsp;' . $row["phone"] . '  </div>
                                      
 </div>                      
                                <div class="card_2_link">
                                        <center> <a class="a_card_2" href=profile2.php?id=' . $row["id"] . '>Veiw more details</a> </center>  
                                </div>
                        </div>

                            <div class="card_2_b">
                                    <div class="card_2_btns">
                                            <a class="call_button_small" href="tel:' . $row["phone"] . ' ">Call</a>
                                            <a class="call_button_small" href="sms:' . $row["phone"] . '">Text</a>
                                            <a class="call_button_small" href="' . $row["email"] . '">Email</a>
                                    </div>
                            </div>
                </div>
             ';
              }
            } else {
              echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
            }
            $conn = null;
          }
        } else {
          echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
        }

        ?>

      </div>
    </div>
  </div>
  <!-- Main container End -->
  <br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br>


  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>