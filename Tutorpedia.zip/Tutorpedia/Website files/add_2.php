<div class="card-adds">
  <!--Advertisement #1-->
  <div class="inner-box">
    <div class="widget-title">
      <h5>Advertisement</h5>
    </div>
    <img src="assets/img/add1/img1.jpg" alt="">
  </div>


  <!--Advertisement #2-->
  <div class="inner-box">
    <div class="widget-title">
      <h5>Advertisement</h5>
    </div>
    <img src="assets/img/add1/img2.jpg" alt="">
  </div>
</div>