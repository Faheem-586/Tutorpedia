<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php require_once('links.php') ?>

  <title>Tutorpedia | Search Result</title>

</head>

<body>

  <!-- Header Section End -->
  <?php include_once('header.php') ?>
  <!-- Page Header Start -->

  <!-- Page Header Start -->
  <div class="header-name">

    Search Results

  </div>
  <!-- Page Header End -->

  <!-- Main container Start -->
  <div style="padding-left:70px; padding-right:70px" class="main-container">
    <div class="row">
      <div class="ad-detail-content ">
 
        <?php
        $where = "";
        $flag = "0";

        if ($_POST["PROVINCE"] <> '')
          $where .= "province = '" . $_POST["PROVINCE"] . "'";
        elseif ($_POST["CITY"] <> '')
          $where .= " and city = '" . $_POST["CITY"] . "'";
        elseif ($_POST["GRADE"] <> '')
          $where .= " and grades = '" . $_POST["GRADE"] . "'";
        elseif ($_POST["SUBJECT"] <> '')
          $where .= " and subjects = '" . $_POST["SUBJECT"] . "'";
        elseif ($_POST["PRICE"] <> '')
          $where .= " and price = '" . $_POST["PRICE"] . "'";
        elseif ($_POST["GENDER"] <> '')
          $where .= " and gender = '" . $_POST["GENDER"] . "'";
        else {
          $flag = "1";
        }
 
        // Create connection
        include_once("DBConnection.php");
        date_default_timezone_set("Asia/Karachi");
        $conn = new DBCon();
 
        if ($flag == "0") {
          if ($conn->Open()) {
            $sql = " SELECT * FROM tutor_info WHERE" . $where;
            $result = $conn->db->query($sql);

            if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                echo '<a class="a_card" href=profile.php?id=' . $row["id"] . '>
                 <div class="card">
                   <img src="' . $row['img'] . '" alt="Avatar" width="200" height="270"">
                   <div class="card_textbox">
                     <h5> ' . $row["name"] . ' </h5> 
                     <span>' . $row["qualification"] . '</span> <br>
                     <a class="call_button_small" href="tel:' . $row["phone"] . ' ">Call</a>
                     <a class="call_button_small" href="sms:' . $row["phone"] . '">Text</a>
                     <a class="call_button_small" href="mailto:' . $row["email"] . '">Email</a>
                  </div>
                 </div>
                 </a>';
              }
            } else {
              echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
            }
            $conn = null;
          }
        } else {
          echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
        } 
        ?>

      </div>
    </div>
  </div>
  <!-- Main container End -->
  <br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br>


  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>