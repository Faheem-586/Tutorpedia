<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Links -->
    <?php include_once('links.php') ?>

    <title>Tutorpedia | Search Result</title>

</head>

<body>

    <!-- Header Section End -->
    <?php include_once('header.php') ?>
    <!-- Page Header Start -->


    <!-- Page Header Start -->
    <div class="header-name">

        Search Results

    </div>
    <!-- Page Header End -->

    <!-- Main container Start -->
    <div style="padding-left:70px; padding-right:70px" class="main-container">
        <div class="row">
            <div class="ad-detail-content ">

                <?php
                // CODE FOR GRADES SEARCH
                // CODE FOR GRADES SEARCH
                if (isset($_GET['grades'])) {
                    $grade = $_GET['grades'];

                    include_once("DBConnection.php");
                    date_default_timezone_set("Asia/Karachi");
                    $conn = new DBCon();

                    // Check connection
                    if ($conn->Open()) {

                        $sql = " SELECT * FROM job_info WHERE grade like '%$grade%'";
                        $result = $conn->db->query($sql) or die("Query error");

                        if ($result->num_rows > 0) {

                            while ($row = $result->fetch_assoc()) {
                                $str1 = $row['sal'];
                                $str2 = substr($str1, 3);

                                echo ' 
                    <div class="card_2">
                             <div class="card_2_a">
                    
                                    <div class="card_2_textbox">
                                    
                                            <div class="card_2_h"> <b class="card_2_titles"> Institute/Job Location: </b> <br>  ' . $row["name"] . ' </div> 
                                            <div class="card_2_h"> <b class="card_2_titles"> Salary:   </b>  &nbsp;' . $str2 . ' pkrs </div>
                                            <div class="card_2_h"> <b class="card_2_titles"> Gender:  </b>    &nbsp;' . $row["gender"] . ' </div>
                                        
                                    </div>
                                    
                                    <div class="card_2_link">
                                            <center> <a class="a_card_2" href=profile2.php?id=' . $row["id"] . '>Veiw more details</a> </center>  
                                    </div>
                            </div>

                                <div class="card_2_b">
                                        <div class="card_2_btns">
                                                <a class="call_button_small" href="tel:' . $row["phone"] . ' ">Call</a>
                                                <a class="call_button_small" href="sms:' . $row["phone"] . '">Text</a>
                                                <a class="call_button_small" href="' . $row["email"] . '">Email</a>
                                        </div>
                                </div>
                    </div>
                 ';
                            }
                            echo "</table>";
                        } else {
                            echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
                        }
                        $conn->db->close();
                    }
                }

                // CODE FOR SUBJECT SEARCH
                // CODE FOR SUBJECT SEARCH
                if (isset($_GET['subjects'])) {
                    $subject = $_GET['subjects'];

                    include_once("DBConnection.php");
                    date_default_timezone_set("Asia/Karachi");
                    $conn = new DBCon();

                    // Check connection
                    if ($conn->Open()) {

                        $sql = " SELECT * FROM job_info WHERE subject like '%$subject%'";
                        $result = $conn->db->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $str1 = $row['sal'];
                                $str2 = substr($str1, 3);

                                echo '  <div class="card_2">
                                <div class="card_2_a">
                       
                                       <div class="card_2_textbox">
                                       
                                               <div class="card_2_h"> <b class="card_2_titles"> Institute/Job Location: </b> <br>  ' . $row["name"] . ' </div> 
                                               <div class="card_2_h"> <b class="card_2_titles"> Salary:   </b>  &nbsp;' . $str2 . ' pkrs </div>
                                               <div class="card_2_h"> <b class="card_2_titles"> Gender:  </b>    &nbsp;' . $row["gender"] . ' </div>
                                           
                                       </div>
                                       
                                       <div class="card_2_link">
                                               <center> <a class="a_card_2" href=profile2.php?id=' . $row["id"] . '>Veiw more details</a> </center>  
                                       </div>
                               </div>
   
                                   <div class="card_2_b">
                                           <div class="card_2_btns">
                                                   <a class="call_button_small" href="tel:' . $row["phone"] . ' ">Call</a>
                                                   <a class="call_button_small" href="sms:' . $row["phone"] . '">Text</a>
                                                   <a class="call_button_small" href="' . $row["email"] . '">Email</a>
                                           </div>
                                   </div>
                       </div>';
                            }
                            echo "</table>";
                        } else {
                            echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
                        }
                        $conn->db->close();
                    }
                }

                // CODE FOR LOCATION SEARCH
                // CODE FOR LOCATION SEARCH
                if (isset($_GET['province'])) {
                    $city = $_GET['province'];

                    include_once("DBConnection.php");
                    date_default_timezone_set("Asia/Karachi");
                    $conn = new DBCon();

                    // Check connection
                    if ($conn->Open()) {

                        $sql = " SELECT * FROM job_info WHERE city like '%$city%'";
                        $result = $conn->db->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $str1 = $row['sal'];
                                $str2 = substr($str1, 3);

                                echo '<div class="card_2">
                                <div class="card_2_a">
                       
                                       <div class="card_2_textbox">
                                       
                                               <div class="card_2_h"> <b class="card_2_titles"> Institute/Job Location: </b> <br> ' . $row["name"] . ' </div> 
                                               <div class="card_2_h"> <b class="card_2_titles"> Salary:   </b>  &nbsp;' . $str2 . ' pkrs </div>
                                               <div class="card_2_h"> <b class="card_2_titles"> Gender:  </b>    &nbsp;' . $row["gender"] . ' </div>
                                           
                                       </div>
                                       
                                       <div class="card_2_link">
                                               <center> <a class="a_card_2" href=profile2.php?id=' . $row["id"] . '>Veiw more details</a> </center>  
                                       </div>
                               </div>
   
                                   <div class="card_2_b">
                                           <div class="card_2_btns">
                                                   <a class="call_button_small" href="tel:' . $row["phone"] . ' ">Call</a>
                                                   <a class="call_button_small" href="sms:' . $row["phone"] . '">Text</a>
                                                   <a class="call_button_small" href="' . $row["email"] . '">Email</a>
                                           </div>
                                   </div>
                       </div>';
                            }
                            echo "</table>";
                        } else {
                            echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
                        }
                        $conn->db->close();
                    }
                }


                ?>

            </div>
        </div>
    </div>
    <!-- Main container End -->

    <br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br>
    <!-- Footer Section Start -->


    <!-- Footer Section Start -->
    <?php include_once('footer.php') ?>
    <!-- Footer Section End -->


</body>

</html>