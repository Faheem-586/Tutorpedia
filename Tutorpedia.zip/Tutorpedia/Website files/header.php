<!-- Header Section Start -->
<div class="header">
  <nav class="navbar navbar-default main-navigation" role="navigation">
    <div class="container">
      <div class="navbar-header">
        <!-- Stat Toggle Nav Link For Mobiles -->
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <!-- End Toggle Nav Link For Mobiles -->
        <a href="index.php"><img src="assets/img/logo.png" alt="Tutorpedia logo" height="60px" width="170px"></a>
      </div>
      <!-- brand and toggle menu for mobile End -->

      <!-- Navbar Start -->
      <div class="collapse navbar-collapse" id="navbar">
        <ul class="nav navbar-nav navbar-right">
          <li class="li-nav2"><a href="index.php">Home</a></li>

          <li class="li-nav2"><a href="contact.php">Contact</a></li>
          <li class="li-nav2"><a href="about.php">About</a></li>

          <li class="li-nav2"> &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; </li>

          <?php if (isset($_SESSION['login_user'])) echo "<li class='li-nav2'><a href='logout.php'><i class='lnr lnr-enter'></i> Logout</a></li>";
          else   echo "<li class='li-nav2'><a href='login.php'><i class='lnr lnr-enter'></i> Log In</a></li>" ?>
          <?php if (isset($_SESSION['login_user'])) echo "<li class='li-nav2'><a href='user.php'> <i class='lnr lnr-user'></i> User: " . $_SESSION['login_user'] . "</a></li>";
          else   echo "<li class='li-nav2'><a href='signup.php'><i class='lnr lnr-user'></i> Sign Up</a></li>" ?>

          <li class="li-nav2"> &nbsp;&nbsp; </li>

          <li class="li-post">
            <a class="btn btn-info btn-pst" href="add_job.php"><span class="fa fa-plus-circle"></span> Add Job</a>
          </li>

          <li class="li-post-l">
            <a class="btn btn-info btn-pst" href="add_tutor.php"><span class="fa fa-plus-circle"></span> Add Tutor</a>
          </li>

          <li class="li-post-l">
            <a class="btn btn-info btn-pst" href="add_institute.php"><span class="fa fa-plus-circle"></span> Add Institute</a>
          </li>
        </ul>
      </div>
      <!-- Navbar End -->
    </div>
  </nav>
  <!-- Off Canvas Navigation -->

  <!--- End Off Canvas Side Menu -->




  <!-- Header Section End -->