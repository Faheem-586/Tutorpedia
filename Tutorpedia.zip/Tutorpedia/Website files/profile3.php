<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php include_once('links.php') ?>

</head>

<body>
  <!-- Header Section End -->
  <?php include_once('header.php') ?>
  <!-- Page Header Start -->

  <br>


  <?php

  include_once("DBConnection.php");
  date_default_timezone_set("Asia/Karachi");
  $conn = new DBCon();

  // Check connection
  if ($conn->Open()) {

    $id = null;

    if (isset($_GET['id']))
      $id = $_GET['id'];

    //$row = null;

    $sql =  "select * from institute_info where id='$id'";
    $result = $conn->db->query($sql);

    $row = mysqli_fetch_array($result);

  ?>

    <!-- Main container Start -->
    <div class="main-container">
      <div class="container">
        <div class="row">
          <div class="col-sm-8">

            <div class="frow add_tutor_bg">
              <div class="add_info">About Institute (Job site)</div>
              <br>
              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="name">Institute Name:</label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts"><?php echo $row['name']; ?></span><br><br>
              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b">Institute Locations:</label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts"><?php echo $row['location']; ?>, <?php echo $row['city']; ?></span><br><br>
                </h5>
              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="phone">Phone:</label>
              </div>
              <div class="fcol-75-b">
                <a class="right_texts" href="tel:<?php echo $row['phone']; ?>"><?php echo $row['phone']; ?> (Click to call)</a><br><br>

              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="email">Email:</label>
              </div>
              <div class="fcol-75-b">
                <a class="right_texts" href="mailto:<?php echo $row['email']; ?>"><?php echo $row['email']; ?> </a><br><br>
              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="phone">Student Admission:</label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts">Student Admissions <?php echo $row['admission']; ?></span><br><br>

              </div>

              <div class="fcol-35-b">
                <label class="add_tutor_label_b" for="email">Teaching Job:</label>
              </div>
              <div class="fcol-75-b">
                <span class="right_texts">Teaching Job <?php echo $row['job']; ?></span><br><br>

              </div>

            </div>
          </div>

        <?php
        $conn = null;
      }
        ?>

        <!-- Addvertisments -->
        <?php include_once('add_2.php') ?>


        </div>


      </div>
    </div>
    </div>
    <!-- Main container End -->


    <!-- Footer Section Start -->
    <?php include_once('footer.php') ?>
    <!-- Footer Section End -->


</body>

</html>