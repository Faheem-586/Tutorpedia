<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <!-- Links -->
  <?php include_once('links.php') ?>

  <title>Tutorpedia | All Jobs</title>


</head>

<body>
  <!-- Header Section Start -->
  <?php include_once('header.php') ?>
  <!-- Header Section End -->


  <!-- Page Header Start -->
  <div class="header-name">

    All Teaching Jobs

  </div>
  <!-- Page Header End -->
  <br>


  <!-- Main container Start -->
  <div class="main-container">
    <div class="container">
      <div class="row">
        <div class="col-sm-8">

          <div id="all_grades" class="all_tutors_tables">
            <h4 class="all_tutor_headers">Search Job by Grades </h4>

            <form action="all_tutor.php" method="POST">
              <div class="frow">
                <div class="fcol-45">
                  <?php echo '<a href=search4.php?grades=1st to 5th> 1st to 5th </a>' ?>
                </div>
                <div class="fcol-45">
                  <?php echo '<a href=search4.php?grades=6th, 7th, 8th> 6th, 7th, 8th </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?grades=9th, 10th> 9th, 10th </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?grades=FA/FSC> FA/FSC </a>' ?>
                </div>

              </div>

          </div>
          <br><br>
          <div id="all_subjects" class="all_tutors_tables">
            <h4 class="all_tutor_headers">Search Job by Subjects </h4>

            <form action="all_tutor.php" method="POST">
              <div class="frow">
                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=English> English </a>' ?>
                </div>
                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=Urdu> Urdu </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=Mathematics> Mathematics </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=Physics> Physics </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=Chemistry> Chemistry </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=Biology> Biology </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=Islamyath> Islamyath </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=Pakstudy> Pakstudy </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=Computer Science> Computer Science </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?subjects=Quran Majeed> Quran Majeed &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </a>' ?>
                </div>

              </div>

          </div>
          <br><br>
          <div id="all_locations" class="all_tutors_tables">
            <h4 class="all_tutor_headers">Search Job by Locations </h4>

            <form action="all_tutor.php" method="POST">
              <div class="frow">
                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Abbottabad> Abbottabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Bahawalpur> Bahawalpur </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Bannu> Bannu </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Buner> Buner </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Charsadda> Charsadda </a>' ?>
                </div>


                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Quetta> Quetta </a>' ?>
                </div>


                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Faisalabad> Faisalabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Gujranwala> Gujranwala </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Gujrat> Gujrat </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Hyderabad> Hyderabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Islamabad> Islamabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Jacobabad> Jacobabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Jhang> Jhang </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Karachi> Karachi </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Kohat> Kohat </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Lahore> Lahore </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Larkana> Larkana </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Mardan> Mardan </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Mirpur Khas> Mirpur Khas </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Multan> Multan </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Murree> Murree </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Nowshera> Nowshera </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Okara> Okara </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Peshawar> Peshawar </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Rahim Yar Khan> Rahim Yar &nbsp;Khan </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Dera Ismail Khan> Dera Ismail Khan </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Rawalpindi> Rawalpindi </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Sahiwal> Sahiwal </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Sargodha> Sargodha </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Sawabi> Sawabi </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Sheikhupura> Sheikhupura </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Sialkot> Sialkot </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Sukkur> Sukkur </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search4.php?province=Taxila> Taxila </a>' ?>
                </div>
              </div>
          </div>
        </div>

        <!-- Advertisement -->
        <?php include_once('add_2.php') ?>

      </div>
    </div>
  </div>
  <!-- Main container End -->

  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>