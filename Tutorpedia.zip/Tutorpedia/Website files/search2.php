<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php require_once('links.php') ?>

  <title>Tutorpedia | Search Result</title>

</head>

<body>

  <!-- Header Section End -->
  <?php include_once('header.php') ?>
  <!-- Page Header Start -->


  <!-- Page Header Start -->
  <div class="header-name">

    Search Results

  </div>
  <!-- Page Header End -->

  <!-- Main container Start -->
  <div style="padding-left:70px; padding-right:70px" class="main-container">
    <div class="row">
      <div class="ad-detail-content ">


        <?php

        // CODE FOR GRADES SEARCH
        // CODE FOR GRADES SEARCH
        if (isset($_GET['grades'])) {
          $grade = $_GET['grades'];

          include_once("DBConnection.php");
          date_default_timezone_set("Asia/Karachi");
          $conn = new DBCon();

          // Check connection
          if ($conn->Open()) {

            $sql = " SELECT * FROM tutor_info WHERE grades like '%$grade%'";
            $result = $conn->db->query($sql) or die("Query error");

            if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                echo '<a class="a_card" href=profile.php?id=' . $row["id"] . '>
                <div class="card">
                  <img src="' . $row['img'] . '" alt="Avatar" width="200" height="270"">
                  <div class="card_textbox">
                    <h5> ' . $row["name"] . ' </h5> 
                    <span>' . $row["qualification"] . '</span> <br>
                    <a class="call_button_small" href="tel:' . $row["phone"] . ' ">Call</a>
                    <a class="call_button_small" href="sms:' . $row["phone"] . '">Text</a>
                    <a class="call_button_small" href="mailto:' . $row["email"] . '">Email</a>
                 </div>
                </div>
                </a>';
              }
              echo "</table>";
            } else {
              echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
            }
            $conn->db->close();
          }
        }

        // CODE FOR SUBJECT SEARCH
        // CODE FOR SUBJECT SEARCH
        if (isset($_GET['subjects'])) {
          $subject = $_GET['subjects'];

          include_once("DBConnection.php");
          date_default_timezone_set("Asia/Karachi");
          $conn = new DBCon();

          // Check connection
          if ($conn->Open()) {

            $sql = " SELECT * FROM tutor_info WHERE subjects like '%$subject%'";


            $result = $conn->db->query($sql);

            if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                echo '<a class="a_card" href=profile.php?id=' . $row["id"] . '>
                <div class="card">
                  <img src="' . $row['img'] . '" alt="Avatar" width="200" height="270"">
                  <div class="card_textbox">
                    <h5> ' . $row["name"] . ' </h5> 
                    <span>' . $row["qualification"] . '</span> <br>
                    <a class="call_button_small" href="tel:' . $row["phone"] . ' ">Call</a>
                    <a class="call_button_small" href="sms:' . $row["phone"] . '">Text</a>
                    <a class="call_button_small" href="mailto:' . $row["email"] . '">Email</a>
                 </div>
                </div>
                </a>';
              }
              echo "</table>";
            } else {
              echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
            }
            $conn->db->close();
          }
        }


        // CODE FOR LOCATION SEARCH
        // CODE FOR LOCATION SEARCH
        if (isset($_GET['province'])) {
          $province = $_GET['province'];

          include_once("DBConnection.php");
          date_default_timezone_set("Asia/Karachi");
          $conn = new DBCon();

          // Check connection
          if ($conn->Open()) {

            $sql = " SELECT * FROM tutor_info WHERE province like '%$province%'";


            $result = $conn->db->query($sql);

            if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                echo '<a class="a_card" href=profile.php?id=' . $row["id"] . '>
                <div class="card">
                  <img src="' . $row['img'] . '" alt="Avatar" width="200" height="270"">
                  <div class="card_textbox">
                    <h5> ' . $row["name"] . ' </h5> 
                    <span>' . $row["qualification"] . '</span> <br>
                    <a class="call_button_small" href="tel:' . $row["phone"] . ' ">Call</a>
                    <a class="call_button_small" href="sms:' . $row["phone"] . '">Text</a>
                    <a class="call_button_small" href="mailto:' . $row["email"] . '">Email</a>
                 </div>
                </div>
                </a>';
              }
              echo "</table>";
            } else {
              echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
            }
            $conn->db->close();
          }
        }


        ?>

      </div>
    </div>
  </div>
  <!-- Main container End -->

  <br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br><br><br><br><br>
  <!-- Footer Section Start -->


  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>