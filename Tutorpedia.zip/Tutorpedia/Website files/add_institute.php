<?php
session_start();
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    die();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Links -->
    <?php include_once('links.php') ?>

    <title>Tutorpedia | Add Institute</title>

</head>

<body>
    <!-- Header Section Start -->
    <?php include_once('header.php') ?>
    <!-- Header Section End -->


    <!-- Page Header Start -->

    <div class="header-name">

        Add Institute

    </div>
    <!-- Page Header End -->


    <?php
    if (isset($_POST["NAME"])) {
        include_once("DBConnection.php");
        date_default_timezone_set("Asia/Karachi");
        $conn = new DBCon();

        if ($conn->Open()) {

            $name = $_POST['NAME'];
            $category = $_POST['CATEGORY'];
            $phone = $_POST['PHONE'];
            $email = $_POST['EMAIL'];

            $city = $_POST['PROVINCE'];
            $location = $_POST['CITY'];

            $admission = $_POST['ADMISSION'];
            $job = $_POST['JOB'];

            $account = $_SESSION['login_email'];

            $sql = "INSERT INTO institute_info (name,  category, phone, email,  city, location, admission, job, account) 
            VALUES ('$name', '$category', '$phone', '$email',  '$city', '$location', '$admission', '$job', '$account')";

            if ($conn->db->query($sql) == TRUE) {
                echo "<h4 id='Success_msg'> ✓ Your information Saved Successfully.<br> <a href='user.php'>  Click here to show all Gigs on your Account...!</a> </h4>";
            } else {
                echo "<h4 id='Error_msg'> ✖ Error Occur.. Please Try Again...!</h4>";
            }

            $conn->db->close();
        }
    }
    ?>

    <br>

    <!-- Main container Start -->
    <div class="main-container">
        <div class="container">
            <div class="row">

                <div class="col-sm-8">

                    <form action="add_institute.php" method="POST" enctype='multipart/form-data'>
                        <div class="frow add_tutor_bg">
                            <div class="add_info">About your Institute</div>


                            <div class="fcol-35">
                                <label class="add_tutor_label" for="name">Institute Name:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">
                                <input class="add_tutor_input" type="text" id="name" name="NAME" placeholder="Enter Your Name.." required>
                            </div>


                            <div class="fcol-35">
                                <label class="add_tutor_label" for="category">Category:</label>
                            </div>
                            <div class="fcol-20">
                                <select name='CATEGORY' style='width=100%' id='category' class='dropdown-product picker2' required>
                                    <option value="">Choose Category</option>
                                    <option value="School">School</option>
                                    <option value="College">College</option>
                                    <option value="Degree College">Degree College</option>
                                    <option value="University">University</option>
                                    <option value="Madrassa">Madrassa</option>
                                    <option value="Tution Center">Tution Center</option>
                                </select>
                            </div>


                            <div class="fcol-35">
                                <label class="add_tutor_label">Institute Locations:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">

                                <div class="fcol-20">
                                    <?php
                                    include_once("DBConnection.php");
                                    date_default_timezone_set("Asia/Karachi");
                                    $conn = new DBCon();
                                    if ($conn->Open()) {
                                        $q = "select * from placeholder_provinces";
                                        $result = $conn->db->query($q);
                                        echo "<select name = 'PROVINCE'  id='province'  class='dropdown-product picker2' required>";
                                        echo "<option value = ''>City</option>";
                                        $farray = array();
                                        while ($row = mysqli_fetch_array($result)) {
                                            echo "<option class='option' value = '" . $row['province'] . "'>" . $row['province'] . "</option selected>";
                                            array_push($farray, array($row['province'] => $row['province']));
                                        }
                                        echo "</select>";
                                        $conn->db->close();
                                    }
                                    ?>
                                </div>


                                <div class="fcol-20">
                                    <select name='CITY' style='width=100%' id='city' class='dropdown-product picker2' required>
                                        <option value="">Location</option>
                                    </select>
                                </div>

                            </div>

                            <div class="fcol-35">
                                <label class="add_tutor_label" for="phone">Phone:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">
                                <input class="add_tutor_input" type="text" id="phone" name="PHONE" placeholder="Enter Your Phone Number.." required>
                            </div>

                            <div class="fcol-35">
                                <label class="add_tutor_label" for="email">Email:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">
                                <input class="add_tutor_input" type="text" id="email" name="EMAIL" placeholder="example@gmail.com.." required>
                            </div>

                            <div class="fcol-35">
                                <label class="add_tutor_label" for="admission">Student Admission:</label>
                            </div>

                            <div class="fcol-20">
                                <select name='ADMISSION' style='width=100%' id='admission' class='dropdown-product picker2' required>
                                    <option value="">Choose Possiblilty</option>
                                    <option value="Opens">Admissions Opens</option>
                                    <option value="Closes">Admissions Closes</option>
                                </select>
                            </div>


                            <div class="fcol-35">
                                <label class="add_tutor_label" for="job">Teaching Job:</label>
                            </div>

                            <div class="fcol-20">
                                <select name='JOB' style='width=100%' id='job' class='dropdown-product picker2' required>
                                    <option value="">Choose Availability</option>
                                    <option value="Available">Available</option>
                                    <option value="Not Available">Not Available</option>
                                </select>
                            </div>

                            <div class="frow">
                                <div class="fcol-25">
                                    <input class="add_tutor_input" type="submit" value="Submit">
                                </div>
                            </div>
                        </div>

                        <br>

                        <br>
                    </form>
                </div>

                <!-- Advertisement -->
                <?php include_once('add_3.php') ?>

            </div>
        </div>
    </div>
    <!-- Main container End -->

    <!-- Footer Section Start -->
    <?php include_once('footer.php') ?>
    <!-- Footer Section End -->

    <!-- SCRIPT for Gender Required property .....  by @faheem  -->
    <script>
        function checkPhoto(target) {
            if (target.files[0].type.indexOf("image") == -1) {
                document.getElementById("photoLabel").innerHTML = "File not supported";
                return false;
            }

            document.getElementById("photoLabel").innerHTML = "";
            return true;
        }

        $(document).ready(function() {
            $('#province').on('change', function() {
                var province = $(this).val();

                if (true) {
                    $.ajax({
                        type: 'POST',
                        url: 'http://localhost/tp/load-data-code-1.php',
                        //  url: 'http://tutorpedia.com.pk/load-data-code-1.php',
                        data: 'province=' + province,
                        success: function(html) {

                            //  alert(html);
                            $('#city').html(html);
                        }
                    });
                } else {
                    $('#state').html('<option value="">Select Province first</option>');
                }
            });

        });
    </script>

</body>

</html>