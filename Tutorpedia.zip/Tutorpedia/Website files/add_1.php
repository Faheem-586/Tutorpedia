<!-- Featured Listings Start -->
<section class="featured-lis">
  <div class="container">
    <div class="row">
      <div class="col-md-12 wow fadeIn" data-wow-delay="0s">
        <h3 class="section-title">Advertisement</h3>

        <div id="new-products">


          <div class="item">
            <div class="product-item">
              <div class="carousel-thumb">
                <img src="assets/img/add2/img1.jpg" alt="">
              </div>
              <a href="ads-details.php" class="item-name">Advertisement</a>
              <!--                <span class="price">Lorem</span>
                -->
            </div>
          </div>


          <div class="item">
            <div class="product-item">
              <div class="carousel-thumb">
                <img src="assets/img/add2/img2.jpg" alt="">
              </div>
              <a href="ads-details.php" class="item-name">Advertisement</a>
              <!--                <span class="price">Lorem</span>
                -->
            </div>
          </div>


          <div class="item">
            <div class="product-item">
              <div class="carousel-thumb">
                <img src="assets/img/add2/img3.jpg" alt="">
              </div>
              <a href="ads-details.php" class="item-name">Advertisement</a>
              <!--                <span class="price">Lorem</span>
                -->
            </div>
          </div>


          <div class="item">
            <div class="product-item">
              <div class="carousel-thumb">
                <img src="assets/img/add2/img4.jpg" alt="">
              </div>
              <a href="ads-details.php" class="item-name">Advertisement</a>
              <!--                <span class="price">Lorem</span>
                -->
            </div>
          </div>


          <div class="item">
            <div class="product-item">
              <div class="carousel-thumb">
                <img src="assets/img/add2/img5.jpg" alt="">
              </div>
              <a href="ads-details.php" class="item-name">Advertisement</a>
              <!--                <span class="price">Lorem</span>
                -->
            </div>
          </div>


          <div class="item">
            <div class="product-item">
              <div class="carousel-thumb">
                <img src="assets/img/add2/img6.jpg" alt="">
              </div>
              <a href="ads-details.php" class="item-name">Advertisement</a>
              <!--                <span class="price">Lorem</span>
                -->
            </div>
          </div>


          <div class="item">
            <div class="product-item">
              <div class="carousel-thumb">
                <img src="assets/img/add2/img7.jpg" alt="">
              </div>
              <a href="ads-details.php" class="item-name">Advertisement</a>
              <!--                <span class="price">Lorem</span>
                -->
            </div>
          </div>


          <div class="item">
            <div class="product-item">
              <div class="carousel-thumb">
                <img src="assets/img/add2/img8.jpg" alt="">
              </div>
              <a href="ads-details.php" class="item-name">Advertisement</a>
              <!--                <span class="price">Lorem</span>
                -->
            </div>
          </div>


        </div>
      </div>
    </div>
  </div>
  <br>
</section>
<!-- Featured Listings End -->