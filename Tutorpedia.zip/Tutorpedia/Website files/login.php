<?php
session_start();
if (isset($_POST["EMAIL"])) {


  $email = $_POST['EMAIL'];
  $pwd = $_POST['PASSWORD'];


  include_once("DBConnection.php");
  date_default_timezone_set("Asia/Karachi");
  $conn = new DBCon();

  if ($conn->Open()) {
    $sql = "select * from users where email='$email' and password='$pwd'";


    $result = $conn->db->query($sql);

    $row = $result->fetch_assoc();

    $usrname = $row['username'];
    $usremail = $row['email'];

    if ($result->num_rows > 0) {
      //  session_register($u_name);
      $_SESSION['login_user'] = $usrname;
      $_SESSION['login_email'] = $usremail;
      header('Location: index.php');
    }

    $conn = NULL;
  }
}
?>

<?php
$error_str = "";
if (isset($_POST["EMAIL"])) {


  include_once("DBConnection.php");
  date_default_timezone_set("Asia/Karachi");
  $conn = new DBCon();

  $email = $_POST['EMAIL'];
  $pwd = $_POST['PASSWORD'];

  /*
                include_once("DBConnection.php");
                date_default_timezone_set("Asia/Karachi");
                $conn = new DBCon();

                // Create connection
             //   $conn = new mysqli($servername, $username, $password, $db);
                // Check connection
                if ($conn->db->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                }
*/

  if ($conn->Open()) {
    $sql = "select * from users where email='$email' and password='$pwd'";
    // echo $sql;
    $result = $conn->db->query($sql);

    if ($result->num_rows > 0) {
      header('Location:index.php');
    } else {
      $error_str = "<h4 id='Error_msg'> ✖ Invalid Username or Password.. </h4>";
    }


    $conn = null;
  }
}
?>
 
<!DOCTYPE html>
<html lang="en">

<head>

  <!-- Links -->
  <?php include_once('links.php') ?>

</head>

<body>

  <!-- Header -->
  <?php include_once('header.php') ?>



  <!-- Page Header Start -->
  <div class="header-name">

    Login to account

  </div>
  <!-- Page Header End -->

  <!-- Content section Start -->
  <section id="content">
    <div class="container">
      <div class="row">
        <div class="col-sm-6 col-sm-offset-4 col-md-4 col-md-offset-4">
          <div class="page-login-form box">
            <h3>
              Login
            </h3>
            <form role="form" action="login.php" method="POST" class="login-form">
              <div class="form-group">
                <div class="input-icon">
                  <i class="icon fa fa-user"></i>
                  <input type="text" id="email" class="form-control" name="EMAIL" placeholder="Email" required>
                </div>
              </div>
              <div class="form-group">
                <div class="input-icon">
                  <i class="icon fa fa-unlock-alt"></i>
                  <input type="password" class="form-control" name="PASSWORD" placeholder="Password" required>
                </div>
              </div>

              <button class="btn btn-common log-btn" type="submit">Login</button>
              <?php {
                echo $error_str;
              }

              ?>
              <br>
            </form>
            <ul class="form-links">
              <li class="pull-right"><a href="signup.php">Don't have an account..?</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Content section End -->


  <div class="vertical_indent1">
    <!-- This section create verticle padding of 20% -->
  </div>

  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>