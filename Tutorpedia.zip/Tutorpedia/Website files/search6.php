<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Links -->
    <?php include_once('links.php') ?>

    <title>Tutorpedia | Search Result</title>

</head>

<body>

    <!-- Header Section End -->
    <?php include_once('header.php') ?>
    <!-- Page Header Start -->


    <!-- Page Header Start -->
    <div class="header-name">

        Search Results

    </div>
    <!-- Page Header End -->

    <!-- Main container Start -->
    <div style="padding-left:70px; padding-right:70px" class="main-container">
        <div class="row">
            <div class="ad-detail-content ">

                <?php

                // CODE FOR LOCATION SEARCH
                // CODE FOR LOCATION SEARCH
                if (isset($_GET['province'])) {
                    $province = $_GET['province'];

                    include_once("DBConnection.php");
                    date_default_timezone_set("Asia/Karachi");
                    $conn = new DBCon();

                    // Check connection
                    if ($conn->Open()) {

                        $sql = " SELECT * FROM institute_info WHERE city like '%$province%'";

                        $result = $conn->db->query($sql) or die("Query error");

                        if ($result->num_rows > 0) {

                            while ($row = $result->fetch_assoc()) {

                                echo ' 
                    <div class="card_2">
                             <div class="card_2_a">
                    
                                    <div class="card_2_textbox">
                                    
                                            <div class="card_2_h"> <b class="card_2_titles"> Institute Name: </b> <br>' . $row["name"] . ' </div> 
                                            <div class="card_2_h"> <b class="card_2_titles"> Student Admission:   </b>  ' . $row["admission"] . ' </div>
                                            <div class="card_2_h"> <b class="card_2_titles"> Teaching Jobs:  </b>' . $row["job"] . ' </div>
                                        
                                    </div>
                                    
                                    <div class="card_2_link">
                                            <center> <a class="a_card_2" href=profile3.php?id=' . $row["id"] . '>Veiw more details</a> </center>  
                                    </div>
                            </div>

                                <div class="card_2_b">
                                        <div class="card_2_btns">
                                                <a class="call_button_small" href="tel:' . $row["phone"] . ' ">Call</a>
                                                <a class="call_button_small" href="sms:' . $row["phone"] . '">Text</a>
                                                <a class="call_button_small" href="' . $row["email"] . '">Email</a>
                                        </div>
                                </div>
                    </div>
                 ';
                            }
                            echo "</table>";
                        } else {
                            echo "<h4 id='Error_msg'> Sorry, We dont have any result according to your search...! </h4>";
                        }
                        $conn->db->close();
                    }
                }

                ?>

            </div>
        </div>
    </div>
    <!-- Main container End -->

    <br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br>
    <br><br><br><br>
    <!-- Footer Section Start -->


    <!-- Footer Section Start -->
    <?php include_once('footer.php') ?>
    <!-- Footer Section End -->


</body>

</html>