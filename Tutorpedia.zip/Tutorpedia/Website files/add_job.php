<?php
session_start();
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    die();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Links -->
    <?php include_once('links.php') ?>

    <title>Tutorpedia | Add Job</title>

</head>

<body>
    <!-- Header Section Start -->
    <?php include_once('header.php') ?>
    <!-- Header Section End -->


    <!-- Page Header Start -->

    <div class="header-name">

        Add Teaching Job

    </div>
    <!-- Page Header End -->


    <?php
    if (isset($_POST["NAME"])) {
        include_once("DBConnection.php");
        date_default_timezone_set("Asia/Karachi");
        $conn = new DBCon();

        if ($conn->Open()) {

            $name = $_POST['NAME'];
            $gender = $_POST['GENDER'];
            $phone = $_POST['PHONE'];
            $email = $_POST['EMAIL'];
            $qualification = $_POST['QUALIFICATION'];
            $teaching_exp = $_POST['TEACHING_EXP'];

            $classes = $_POST['CLASSES'];

            $city = $_POST['PROVINCE'];
            $location = $_POST['CITY'];

            $salary = $_POST['SALARY'];

            $age = '';
            $grades = '';
            $subjects = '';
            $languages = '';

            //  echo $classes;

            if (!empty($_POST['AGE1'])) {
                $age = $_POST['AGE1'] . " years  to  " . $_POST['AGE2'] . " years";
            }


            if (!empty($_POST['GRADES'])) {
                foreach ($_POST['GRADES'] as $grd) {
                    $grades .= $grd . ", <br>";
                }
            }

            if (!empty($_POST['SUBJECTS'])) {
                foreach ($_POST['SUBJECTS'] as $sub) {
                    $subjects .= $sub . ", <br>";
                }
            }

            if (!empty($_POST['LANGUAGE'])) {
                foreach ($_POST['LANGUAGE'] as $lang) {
                    $languages .= $lang . ", &nbsp;&nbsp;";
                }
            }

            $account = $_SESSION['login_email'];

            $sql = "INSERT INTO job_info (name, age, gender, phone, email, qualification, experiance, lang, grade, subject, location, city, sal, classes, account) 
    VALUES ('$name', '$age','$gender','$phone', '$email','$qualification','$teaching_exp', '$languages','$grades','$subjects', '$location', '$city', '$salary', '$classes',  '$account')";

            //  echo $sql;

            if ($conn->db->query($sql) == TRUE) {
                echo "<h4 id='Success_msg'> ✓ Your information Saved Successfully.<br> <a href='user.php'>  Click here to show all Gigs on your Account...!</a> </h4>";
            } else {
                echo "<h4 id='Error_msg'> ✖ Error Occur.. Please Try Again...!</h4>";
            }

            $conn->db->close();
        }
    }
    ?>
    <br>
    <!-- Main container Start -->
    <div class="main-container">
        <div class="container">
            <div class="row">

                <div class="col-sm-8">

                    <form action="add_job.php" method="POST" enctype='multipart/form-data'>
                        <div class="frow add_tutor_bg">
                            <div class="add_info">About your Institute</div>
                            <div class="fcol-35">
                                <label class="add_tutor_label" for="name">Institute Name:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">
                                <input class="add_tutor_input" type="text" id="name" name="NAME" placeholder="Enter Your Name.." required>
                            </div>


                            <div class="fcol-35">
                                <label class="add_tutor_label">Institute Locations:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">

                                <div class="fcol-20">
                                    <?php
                                    include_once("DBConnection.php");
                                    date_default_timezone_set("Asia/Karachi");
                                    $conn = new DBCon();
                                    if ($conn->Open()) {
                                        $q = "select * from placeholder_provinces";
                                        $result = $conn->db->query($q);
                                        echo "<select name = 'PROVINCE'  id='province'  class='dropdown-product picker2' required>";
                                        echo "<option value = ''>City</option>";
                                        $farray = array();
                                        while ($row = mysqli_fetch_array($result)) {
                                            echo "<option class='option' value = '" . $row['province'] . "'>" . $row['province'] . "</option selected>";
                                            array_push($farray, array($row['province'] => $row['province']));
                                        }
                                        echo "</select>";
                                        $conn->db->close();
                                    }
                                    ?>
                                </div>

                                <div class="fcol-20">
                                    <select name='CITY' style='width=100%' id='city' class='dropdown-product picker2' required>
                                        <option value="">Location</option>
                                    </select>
                                </div>

                            </div>

                            <div class="fcol-35">
                                <label class="add_tutor_label" for="phone">Phone:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">
                                <input class="add_tutor_input" type="text" id="phone" name="PHONE" placeholder="Enter Your Phone Number.." required>
                            </div>

                            <div class="fcol-35">
                                <label class="add_tutor_label" for="email">Email:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">
                                <input class="add_tutor_input" type="text" id="email" name="EMAIL" placeholder="example@gmail.com.." required>
                            </div>

                        </div>

                        <br>
                        <div class="frow add_tutor_bg">
                            <div class="add_info">About the Job you posting</div>

                            <div class="fcol-35">
                                <label class="add_tutor_label" for="age">Age:</label>

                            </div>

                            <div style="padding-bottom:10px" class="fcol-75">
                                <div class="fcol-subtitles">
                                    <small>Enter the Range of tutor's Age; </small>
                                </div>
                                From <input class="add_tutor_input2" type="number" id="age1" name="AGE1" placeholder="From" required>
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                To <input class="add_tutor_input2" type="number" id="age2" name="AGE2" placeholder="To" required>
                            </div>



                            <div class="fcol-35">
                                <label class="add_tutor_label">Gender: </label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75" style="padding-top:5px">

                                <input class="add_tutor_input" type="Radio" id="gender" name="GENDER" value="Male" required> Male <br>
                                <input class="add_tutor_input" type="Radio" id="gender" name="GENDER" value="Female" required> Female <br>
                            </div>

                            <div class="fcol-35">
                                <label class="add_tutor_label" for="qualification">Minimum Qualification:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">
                                <input class="add_tutor_input" type="text" id="qualification" name="QUALIFICATION" placeholder="e.g; MS(Physics).." required>
                            </div><br>

                            <div class="fcol-35">
                                <label class="add_tutor_label" for="teaching_exp">Minimum Experiance:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">
                                <input class="add_tutor_input" type="number" id="teaching_exp" name="TEACHING_EXP" placeholder="  Teaching Experiance.." required> Years
                            </div>

                            <div class="fcol-35">
                                <label class="add_tutor_label">Grade:</label>
                            </div>

                            <div style="padding-bottom:10px" class="fcol-75">
                                <div class="fcol-subtitles">
                                    <small>Check only those grades which are according to your requirements; </small>
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="grades" name="GRADES[]" value="1st to 5th"> 1st to 5th
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="grades" name="GRADES[]" value="6th, 7th, 8th"> 6th, 7th, 8th
                                </div>


                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="grades" name="GRADES[]" value="9th, 10th"> 9th, 10th
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="grades" name="GRADES[]" value="FA/FSC"> FA/FSC
                                </div>

                            </div>

                            <div class="fcol-35">
                                <label class="add_tutor_label">Subject:</label>
                            </div>

                            <div style="padding-bottom:15px" class="fcol-75">
                                <div class="fcol-subtitles">
                                    <small>Check only those subjects which are according to your requirements; </small>
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="subjects" name="SUBJECTS[]" value="English"> English
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="subjects" name="SUBJECTS[]" value="Urdu"> Urdu
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="subjects" name="SUBJECTS[]" value="Mathematics"> Mathematics
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="subjects" name="SUBJECTS[]" value="Physics"> Physics
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="subjects" name="SUBJECTS[]" value="Chemistry"> Chemistry
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="subjects" name="SUBJECTS[]" value="Biology"> Biology
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="subjects" name="SUBJECTS[]" value="Islamyath"> Islamyath
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="subjects" name="SUBJECTS[]" value="Pakstudy"> Pakstudy
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="subjects" name="SUBJECTS[]" value="Computer Science"> Computer Science
                                </div>

                            </div>


                            <div class="fcol-35">
                                <label class="add_tutor_label" for="teaching_exp">Monthly Salary:</label>
                            </div>
                            <div style="padding-bottom:20px" class="fcol-75">
                                <div class="fcol-subtitles">
                                    <small>Select Expecting Monthly Salary you offers: </small>
                                </div>
                                <?php
                                include_once("DBConnection.php");
                                date_default_timezone_set("Asia/Karachi");
                                $conn = new DBCon();
                                if ($conn->Open()) {
                                    $q = "select * from placeholder_salary";
                                    $result = $conn->db->query($q);
                                    echo "<select name = 'SALARY'  id='salary'  class='dropdown-product picker2' required>";
                                    echo "<option value = ''>Fee per subject </option>";
                                    $farray = array();
                                    while ($row = mysqli_fetch_array($result)) {
                                        echo "<option class='option' value = '" . $row['all_salaries'] . "'>" . $row['all_salaries'] . "</option selected>";
                                        array_push($farray, array($row['all_salaries'] => $row['all_salaries']));
                                    }
                                    echo "</select>";
                                    $conn->db->close();
                                }
                                ?>

                            </div>

                            <div class="fcol-35">
                                <label class="add_tutor_label" for="teaching_exp">Number of classes:</label>
                            </div>
                            <div style="padding-bottom:10px" class="fcol-75">
                                <div class="fcol-subtitles">
                                    <small>Enter Expecting number of classes he/she must attend: </small>
                                </div>

                                <input class="add_tutor_input" type="number" id="classes" name="CLASSES" placeholder=" Number of classes.." required> Classes
                            </div>
                            <div class="fcol-35">
                                <label class="add_tutor_label">Language(s):</label>
                            </div>

                            <div class="fcol-75">
                                <div class="fcol-subtitles">
                                    <small>Check the Expecting language in which he/she must teach; </small>
                                </div>


                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Pashto"> Pashto
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Punjabi"> Punjabi
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="English"> English
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Urdu"> Urdu
                                </div>


                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Hindko"> Hindko
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Sindhi"> Sindhi
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Balochi"> Balochi
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Saraiki"> Saraiki
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Kashmiri"> Kashmiri
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Persian"> Persian
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Chitrali"> Chitrali
                                </div>

                                <div class="fcol-20">
                                    <input class="add_tutor_input" type="checkbox" id="language" name="LANGUAGE[]" value="Gujarati"> Gujarati
                                </div>

                            </div>
                        </div>
                        <br>

                        <div class="frow">
                            <div class="fcol-25">
                                <input class="add_tutor_input" type="submit" value="Submit">
                            </div>
                        </div>

                        <br>
                    </form>
                </div>

                <!-- Advertisement -->
                <?php include_once('add_3.php') ?>

            </div>
        </div>
    </div>
    <!-- Main container End -->

    <!-- Footer Section Start -->
    <?php include_once('footer.php') ?>
    <!-- Footer Section End -->

    <!-- SCRIPT for Gender Required property .....  by @faheem  -->
    <script>
        function checkPhoto(target) {
            if (target.files[0].type.indexOf("image") == -1) {
                document.getElementById("photoLabel").innerHTML = "File not supported";
                return false;
            }

            document.getElementById("photoLabel").innerHTML = "";
            return true;
        }

        $(document).ready(function() {
            $('#province').on('change', function() {
                var province = $(this).val();

                if (true) {
                    $.ajax({
                        type: 'POST',
                        url: 'http://localhost/tp/load-data-code-1.php',
                        //  url: 'http://tutorpedia.com.pk/load-data-code-1.php',
                        data: 'province=' + province,
                        success: function(html) {

                            //  alert(html);
                            $('#city').html(html);

                        }
                    });
                } else {
                    $('#state').html('<option value="">Select Province first</option>');
                }
            });

        });
    </script>

</body>

</html>