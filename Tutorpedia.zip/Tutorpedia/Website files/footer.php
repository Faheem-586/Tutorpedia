 <footer>

     <!-- Copyright Start  -->
     <div id="copyright">
         <div class="container">
             <div class="row">
                 <div class="col-md-12">
                     <div class="site-info pull-left">
                         <p>Copyright © 2019<a href="index.php"> Tutorpedia</a>. All rights reserved.
                     </div>
                     <div class="site-info pull-right">
                         Designed by <a rel="nofollow" href="https://www.facebook.com/mohammad.faheem.56863221">Muhammad Faheem</a></p>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <!-- Copyright End -->

 </footer>


 <!-- Go To Top Link -->
 <a href="#" class="back-to-top">
     <i class="fa fa-angle-up"></i>
 </a>

 <!-- Main JS  -->
 <script type="text/javascript" src="assets/js/jquery-min.js"></script>
 <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
 <script type="text/javascript" src="assets/js/material.min.js"></script>
 <script type="text/javascript" src="assets/js/material-kit.js"></script>
 <script type="text/javascript" src="assets/js/jquery.parallax.js"></script>
 <script type="text/javascript" src="assets/js/owl.carousel.min.js"></script>
 <script type="text/javascript" src="assets/js/wow.js"></script>
 <script type="text/javascript" src="assets/js/main.js"></script>
 <script type="text/javascript" src="assets/js/jquery.counterup.min.js"></script>
 <script type="text/javascript" src="assets/js/waypoints.min.js"></script>
 <script type="text/javascript" src="assets/js/jasny-bootstrap.min.js"></script>
 <script src="assets/js/bootstrap-select.min.js"></script>