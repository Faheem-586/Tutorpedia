 <!DOCTYPE html>
 <html lang="en">

 <head>
   <!-- Links -->
   <?php include_once('links.php') ?>

 </head>

 <body>

   <!-- Header -->
   <?php include_once('header.php') ?>

   <!-- Page Header Start -->
   <div class="header-name">
     Create Account
   </div>
   <!-- Page Header End -->

   <!-- Content section Start -->
   <section id="content">
     <div class="container">
       <div class="row">
         <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
           <div class="page-login-form box">
             <h3>
               Sign up
             </h3>
             <form role="form" class="login-form" method="POST">
               <div class="form-group">
                 <div class="input-icon">
                   <i class="icon fa fa-user"></i>
                   <input type="text" id="username" class="form-control" name="USERNAME" placeholder="Username" maxlength="12" required>
                 </div>
               </div>
               <div class="form-group">
                 <div class="input-icon">
                   <i class="icon fa fa-envelope"></i>
                   <input type="email" required id="email" class="form-control" name="EMAIL" placeholder="Email Address" required>
                 </div>
               </div>
               <div class="form-group">
                 <div class="input-icon">
                   <i class="icon fa fa-unlock-alt"></i>
                   <input type="password" id="password" class="form-control" name="PASSWORD" placeholder="Password (6 characters minimum)" minlength="6" required>
                 </div>
               </div>

               <br>
               <input class="btn btn-common log-btn" type="submit" value="Register">

               <?php
                if (isset($_POST["USERNAME"])) {


                  include_once("DBConnection.php");
                  date_default_timezone_set("Asia/Karachi");
                  $conn = new DBCon();

                  $conn->open();
                  $usrname = $_POST['USERNAME'];
                  $email = $_POST['EMAIL'];
                  $pswrd = $_POST['PASSWORD'];

                  $sql = null;

                  $sql = "INSERT INTO users (username, email, password) VALUES ('$usrname', '$email','$pswrd')";
                  // echo $sql;
                  if ($conn->db->query($sql) ==  TRUE) {
                    echo " <ul class='form-links'>
                 <li class='pull-left'><h4 id='Success_msg'> ✓ Thank You...! </h4></li>
                 <li class='pull-right'><h4 id='Success_msg'><a href='login.php'>Now Login here..!</a></h4></li>
                </ul><br>";
                  } else {
                    echo "<h5 id='Error_msg'> ✖ Already have an account on this email...Try another..!</h5><br>";
                  }
                  $conn->db->close();
                }
                ?>
             </form>
             <center><a href="login.php">Already have an account..?</a></center>

           </div>
         </div>
       </div>
     </div>
   </section>
   <!-- Content section End -->

   <div class="vertical_indent1">
     <!-- This section create verticle padding of 20% -->
   </div>


   <!-- Footer Section Start -->
   <?php include_once('footer.php') ?>
   <!-- Footer Section End -->




 </body>

 </html>