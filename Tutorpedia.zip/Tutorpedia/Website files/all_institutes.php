<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <!-- Links -->
  <?php include_once('links.php') ?>

  <title>Tutorpedia | All Institutes</title>


</head>

<body>
  <!-- Header Section Start -->
  <?php include_once('header.php') ?>
  <!-- Header Section End -->


  <!-- Page Header Start -->
  <div class="header-name">

    All Institutes

  </div>
  <!-- Page Header End -->
  <br>


  <!-- Main container Start -->
  <div class="main-container">
    <div class="container">
      <div class="row">
        <div class="col-sm-8">


          <br><br>
          <div id="all_locations" class="all_tutors_tables">
            <h4 class="all_tutor_headers">Search Institute by Locations </h4>

            <form action="all_institutes.php" method="POST">
              <div class="frow">
                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Abbottabad> Abbottabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Bahawalpur> Bahawalpur </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Bannu> Bannu </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Buner> Buner </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Charsadda> Charsadda </a>' ?>
                </div>


                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Quetta> Quetta </a>' ?>
                </div>


                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Faisalabad> Faisalabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Gujranwala> Gujranwala </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Gujrat> Gujrat </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Hyderabad> Hyderabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Islamabad> Islamabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Jacobabad> Jacobabad </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Jhang> Jhang </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Karachi> Karachi </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Kohat> Kohat </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Lahore> Lahore </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Larkana> Larkana </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Mardan> Mardan </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Mirpur Khas> Mirpur Khas </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Multan> Multan </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Murree> Murree </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Nowshera> Nowshera </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Okara> Okara </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Peshawar> Peshawar </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Rahim Yar Khan> Rahim Yar Khan </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Dera Ismail Khan> Dera Ismail Khan </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Rawalpindi> Rawalpindi </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Sahiwal> Sahiwal </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Sargodha> Sargodha </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Sawabi> Sawabi </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Sheikhupura> Sheikhupura </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Sialkot> Sialkot </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Sukkur> Sukkur </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search6.php?province=Taxila> Taxila </a>' ?>
                </div>
              </div>
          </div>
        </div>

        <!-- Advertisement -->
        <?php include_once('add_2.php') ?>

      </div>
    </div>
  </div>
  <!-- Main container End -->

  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>