<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <!-- Links -->
  <?php include_once('links.php') ?>


  <title>Tutorpedia</title>

</head>

<body>


  <!-- Header -->
  <?php include_once('header.php') ?>
  <ul class="navbar-nav2">
    <li><a href="all_tutors.php">All Tutors&nbsp;&nbsp;&nbsp; &nbsp; </a></li>
    <li><a href="all_jobs.php">All Tuition jobs</a></li>
    <li><a href="all_institutes.php">All Institutes</a></li>
  </ul>

  <!-- Start intro section -->
  <section id="intro" class="section-intro">

    <div class="overlay">
      <div class="container">
        <div class="main-text">
          <br> <br> <br>
          <h1 class="intro-title">Welcome To <span style="color:#48ACEF">Tutorpedia</span></h1>
          <p class="sub-title">The best website for finding tutors and tuition jobs all over the Pakistan</p>



          <div class="row search-bar">
            <div class="add-post">
              You are a student and searching for a tutor.... CLICK HERE
              <div class="add-post-btn">
                <a href="search_tutor.php" class="btn btn-common" type="submit">Search Tutor</a>
              </div>
            </div>
          </div>

          <br>

          <div class="row search-bar">
            <div class="add-post">
              You are a tutor and searching for a teaching job.... CLICK HERE
              <div class="add-post-btn">
                <a href="search_tution.php" class="btn btn-common" type="submit">Search Tuition</a>
              </div>
            </div>
          </div>

        </div>
      </div>
  </section>
  <!-- end intro section -->


  <div class="link-title">
    <a class="link-title-a" href="add_tutor.php"> Add Yourself as Tutor... Click here </a>
  </div>

  <br>
  <br>

  <!-- Counter Section Start -->
  <section id="counter">
    <div class="container">
      <div class="row">

        <div class="add-post">
          You are hiring teachers.... <br>CLICK HERE TO ADD TEACHING JOBS
          <div class="add-post-btn">
            <a href="add_job.php" class="btn btn-common btn-search" type="submit">Add Job</a>
          </div>
        </div>


      </div>
    </div>
  </section>
  <!-- Counter Section End -->
  <div class="link-title">
    <a class="link-title-a" href="add_institute.php"> Add Your Institute... Click here </a>
  </div>

  <br>
  <br>

  <!-- Advertisement -->
  <?php include_once('add_1.php') ?>
  <br>
  </div>

  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->

  <!-- SCRIPT for sidebar .....  by @faheem  -->
  <script>
    /********************************************************* 
		Dependent drop downs code			Coded by: @faheem
		**********************************************************/
    $(document).ready(function() {
      $('#province').on('change', function() {
        var province = $(this).val();
        //  alert(province);
        if (true) {
          $.ajax({
            type: 'POST',
            url: 'http://localhost/tp/load-data-code-1.php',
            //  url: 'http://tutorpedia.com.pk/load-data-code-1.php',
            data: 'province=' + province,
            success: function(html) {

              //       alert(html);
              $('#city').html(html);

            }
          });
        } else {
          $('#state').html('<option value="">Select Province first</option>');
        }
      });

    });
  </script>


</body>

</html>