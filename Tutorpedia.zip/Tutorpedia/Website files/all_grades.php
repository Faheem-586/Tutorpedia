<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php include_once('links.php') ?>

  <title>Tutorpedia | All Grades </title>

</head>

<body>
  <!-- Header Section Start -->
  <?php include_once('header.php') ?>
  <!-- Header Section End -->


  <!-- Page Header Start -->
  <div class="header-name">

    Search Tutor by Grade

  </div>
  <!-- Page Header End -->
  <br>
  <!-- Main container Start -->
  <div class="main-container">
    <div class="container">
      <div class="row">
        <div class="col-sm-8">

          <div id="all_grades" class="all_tutors_tables">
            <h4 class="all_tutor_headers"> All Grades</h4>

            <form action="all_tutor.php" method="POST">
              <div class="frow">
                <div class="fcol-45">
                  <?php echo '<a href=search2.php?grades=1st to 5th> 1st to 5th </a>' ?>
                </div>
                <div class="fcol-45">
                  <?php echo '<a href=search2.php?grades=6th, 7th, 8th> 6th, 7th, 8th </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search2.php?grades=9th, 10th> 9th, 10th </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search2.php?grades=FA/FSC> FA/FSC </a>' ?>
                </div>

              </div>

          </div>

        </div>


        <!-- Advertisement -->
        <?php include_once('add_2.php') ?>



      </div>
    </div>
  </div>
  <!-- Main container End -->


  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->

</body>

</html>