<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php include_once('links.php') ?>

  <title>Tutorpedia | Contact us</title>

</head>

<body>

  <!-- Header Section End -->
  <?php include_once('header.php') ?>
  <!-- Page Header Start -->

  <div class="header-name">

    Contact us

  </div>
  <!-- Page Header End -->
  <br>


  <!-- Main container Start -->
  <div class="main-container">
    <div class="container">
      <div class="row">
        <div class="col-sm-8">
          <div class="row">


            <div class="founder_container">

              <div class="founder_pic">
                <img style="border-radius: 15px" class="pic_container" src="assets\img\founder.jpg" alt="">
              </div>

              <div class="founder_info">
                Founder:<br>
                <h3> Qaisar Afridi<br></h3>
                <br> 📱 Phone: <a href="tel:+92 0333 0567120"> +92&nbsp;0333&nbsp;0567120</a> <br>
                <br> 📧 Email: <a href="mailto:gblack348@gmail.com">gblack348@gmail.com</a> <br>
                <br> <img style="width:20px" src="assets\img\facebook.png" alt=""> Facebook: <a href="https://www.facebook.com/jinnydotshaa">facebook/jinnydotshaa</a>
              </div>


            </div>

          </div>
        </div><!-- col-sm-8 -->

        <!-- Advertisement -->
        <?php include_once('add_2.php') ?>

      </div>
    </div>
  </div>
  <!-- Main container End -->


  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>