<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php include_once('links.php') ?>

  <title>Tutorpedia | User Account</title>

</head>

<body>

  <!-- Header -->
  <?php include_once('header.php') ?>


  <!-- Page Header Start -->
  <div class="header-name">

    User Account

  </div>
  <!-- Page Header End -->
  <br>


  <!-- Main container Start style="border: 1px solid #5f00f8;-->
  <div class="main-container">
    <div style="padding-left: 40px; padding-right: 40px" class="content-wrapper ">
      <div class="row ">
        <h4 style="padding-left: 10px; padding-bottom: 10px">You have the following Gigs on your account; </h4>
        <form method="POST">
          <!-- Advanced Tables -->
          <div class="panel panel-default ">
            <h3 style="padding-left: 20px; padding-top: 10px">Tutor Gigs: </h3>
            <div class="panel-body">
              <div class="table-responsive">
                <?php

                date_default_timezone_set("Asia/Karachi");
                include("DBConnection.php");
                $con = new DBCon();

                if ($con->Open()) {

                  $account = $_SESSION['login_email'];

                  $sql = " SELECT * FROM tutor_info WHERE account='" . $account . "'";
                  $result = $con->db->query($sql) or die("Query error");
                  if ($result->num_rows > 0) {
                ?>
                    <table style="border: 1px solid #393939" class="table table-striped table-bordered" id="dataTables-example">
                      <thead>
                        <tr>
                          <th style="border: 1px solid #393939">Name</th>
                          <th style="border: 1px solid #393939">Age</th>
                          <th style="border: 1px solid #393939">Gender</th>
                          <th style="border: 1px solid #393939">Phone</th>
                          <th style="border: 1px solid #393939">Email</th>
                          <th style="border: 1px solid #393939">Qualification</th>
                          <th style="border: 1px solid #393939">Experiance</th>
                          <th style="border: 1px solid #393939">Languages</th>
                          <th style="border: 1px solid #393939">Grades</th>
                          <th style="border: 1px solid #393939">Subjects</th>
                          <th style="border: 1px solid #393939">Address</th>
                          <th style="border: 1px solid #393939">Price</th>
                          <th style="border: 1px solid #393939">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php

                        while ($row = $result->fetch_assoc()) {
                          //   $str = $row["did"];
                          //    $did = explode("D", $str);
                          // echo $did[1];
                        ?>
                          <tr>

                            <td style="border: 1px solid #393939"><?php echo $row["name"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["age"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["gender"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["phone"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["email"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["qualification"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["teaching_exp"];  ?> years of teaching experiance </td>
                            <td style="border: 1px solid #393939"><?php echo $row["languages"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["grades"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["subjects"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["province"];  ?> , <?php echo $row["city"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["price"];  ?> </td>

                            <td style="border: 1px solid #393939">

                              <!--
<a style="margin-top: 10px" href="edit_tutor.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-xs edit-btn">Edit</a>
-->

                              <a style="margin-top: 10px" href="delete_tutor.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-xs dlt-btn">Delete</a>
                              <a style="margin-top: 10px" href="profile.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-xs dlt-btn">Veiw</a>

                            </td>

                          </tr>
                    <?php
                        }
                      } else {
                        echo "<h4 id='Error_msg'>  No Tutor Gig found..! <br><br> <a href='add_tutor.php'> Click here to create one...! </a> </h4>";
                      }
                    }

                    ?>

                      </tbody>
                    </table>
              </div>
            </div>
          </div>

          <!--End Advanced Tables -->

          <!-- Advanced Tables -->
          <div class="panel panel-default ">
            <h3 style="padding-left: 20px; padding-top: 10px">Job Gigs: </h3>
            <div class="panel-body">
              <div class="table-responsive">
                <?php

                if ($con->Open()) {

                  $account = $_SESSION['login_email'];

                  $sql = " SELECT * FROM job_info WHERE account='" . $account . "'";
                  $result = $con->db->query($sql) or die("Query error");
                  if ($result->num_rows > 0) {
                ?>
                    <table class="table table-striped table-bordered" id="dataTables-example">
                      <thead>
                        <tr>
                          <th style="border: 1px solid #393939">Institute Name</th>
                          <th style="border: 1px solid #393939">Age Required</th>
                          <th style="border: 1px solid #393939">Gender Required</th>
                          <th style="border: 1px solid #393939">Phone</th>
                          <th style="border: 1px solid #393939">Email</th>
                          <th style="border: 1px solid #393939">Address</th>
                          <th style="border: 1px solid #393939">Qualification Required</th>
                          <th style="border: 1px solid #393939">Experiance Required</th>
                          <th style="border: 1px solid #393939">Languages Required</th>
                          <th style="border: 1px solid #393939">Grades</th>
                          <th style="border: 1px solid #393939">Subjects</th>
                          <th style="border: 1px solid #393939">Salary</th>
                          <th style="border: 1px solid #393939">Classes to Attend</th>
                          <th style="border: 1px solid #393939">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php

                        while ($row = $result->fetch_assoc()) {
                          //   $str = $row["did"];
                          //    $did = explode("D", $str);
                          // echo $did[1];
                          $sal1 = $row["sal"];
                          $sal2 = $str2 = substr($sal1, 3);

                        ?>
                          <tr>


                            <td style="border: 1px solid #393939"><?php echo $row["name"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["age"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["gender"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["phone"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["email"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["location"];  ?> , <?php echo $row["city"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["qualification"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["experiance"];  ?> years of teaching experiance </td>
                            <td style="border: 1px solid #393939"><?php echo $row["lang"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["grade"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["subject"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $sal2  ?> pkrs </td>
                            <td style="border: 1px solid #393939"><?php echo $row["classes"];  ?> classes </td>
                            <td style="border: 1px solid #393939">

                              <!--
<a style="margin-top: 10px" href="edit_job.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-xs edit-btn">Edit</a>
-->

                              <a style="margin-top: 10px" href="delete_job.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-xs dlt-btn">Delete</a>
                              <a style="margin-top: 10px" href="profile2.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-xs dlt-btn">Veiw</a>
                            </td>

                          </tr>
                    <?php
                        }
                      } else {
                        echo "<h4 id='Error_msg'>  No Job Gig found..! <br><br> <a href='add_job.php'> Click here to create one...! </a> </h4>";
                      }
                    }

                    ?>

                      </tbody>
                    </table>
              </div>
            </div>
          </div>

          <!--End Advanced Tables -->



          <!-- Advanced Tables -->
          <div class="panel panel-default ">
            <h3 style="padding-left: 20px; padding-top: 10px">Institute Gigs: </h3>
            <div class="panel-body">
              <div class="table-responsive">
                <?php
                if ($con->Open()) {

                  $account = $_SESSION['login_email'];

                  $sql = " SELECT * FROM institute_info WHERE account='" . $account . "'";
                  $result = $con->db->query($sql) or die("Query error");
                  if ($result->num_rows > 0) {
                ?>
                    <table class="table table-striped table-bordered" id="dataTables-example">
                      <thead>
                        <tr>
                          <th style="border: 1px solid #393939">Institute Name</th>
                          <th style="border: 1px solid #393939">Category</th>
                          <th style="border: 1px solid #393939">Phone</th>
                          <th style="border: 1px solid #393939">Email</th>
                          <th style="border: 1px solid #393939">Address</th>
                          <th style="border: 1px solid #393939">Admission Status</th>
                          <th style="border: 1px solid #393939">Job Status</th>
                          <th style="border: 1px solid #393939">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php


                        while ($row = $result->fetch_assoc()) {
                          //   $str = $row["did"];
                          //    $did = explode("D", $str);
                          // echo $did[1];
                        ?>
                          <tr>

                            <td style="border: 1px solid #393939"><?php echo $row["name"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["category"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["phone"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["email"];  ?> </td>
                            <td style="border: 1px solid #393939"><?php echo $row["location"];  ?> , <?php echo $row["city"];  ?> </td>
                            <td style="border: 1px solid #393939">Admission <?php echo $row["admission"];  ?> </td>
                            <td style="border: 1px solid #393939">Job <?php echo $row["job"];  ?> </td>
                            <td style="border: 1px solid #393939">

                              <!--
<a style="margin-top: 10px" href="edit_institute.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-xs edit-btn">Edit</a>
-->

                              <a style="margin-top: 10px" href="delete_institute.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-xs dlt-btn">Delete</a>
                              <a style="margin-top: 10px" href="profile3.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-xs dlt-btn">Veiw</a>
                            </td>

                          </tr>
                    <?php
                        }
                      } else {
                        echo "<h4 id='Error_msg'>  No Institute Gig found..!  <br><br> <a href='add_institute.php'> Click here to create one...! </a>  </h4>";
                      }
                    }
                    $con = null;
                    ?>

                      </tbody>
                    </table>
              </div>
            </div>
          </div>

          <!--End Advanced Tables -->
        </form>
      </div>
    </div>
  </div>
  </div>
  <!-- Main container End -->

  <div class="vertical_indent1">
    <!-- This section create verticle padding of 20% -->
  </div>

  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>