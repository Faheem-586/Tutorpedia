<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php include_once('links.php') ?>

</head>

<body>
  <!-- Header -->
  <?php include_once('header.php') ?>


  <!-- Start intro section -->
  <section id="intro" class="section-intro">
    <div class="overlay">
      <div class="container">
        <div class="main-text">
          <h1 class="intro-title">Search<span style="color:#48ACEF"> Tutors</span></h1>
          <br>

          <!-- Start Search box -->
          <div class="row search-bar">

            <form class="search-form" action="search.php" method="POST">
 
              <div style="padding-bottom:20px" class="col-md-3 col-sm-6 search-col">
                <div class="input-group-addon search-category-container">

                  <?php
                  include_once("DBConnection.php");
                  date_default_timezone_set("Asia/Karachi");
                  $conn = new DBCon();
                  if ($conn->Open()) {
                    $q = "select * from placeholder_provinces";
                    $result = $conn->db->query($q);
                    echo "<select name = 'PROVINCE'  id='province'  class='dropdown-product picker'>";
                    echo "<option value = ''>City</option>";
                    $farray = array();
                    while ($row = mysqli_fetch_array($result)) {
                      echo "<option class='option' value = '" . $row['province'] . "'>" . $row['province'] . "</option selected>";
                      array_push($farray, array($row['province'] => $row['province']));
                    }
                    echo "</select>";
                  }
                  $conn->db->close();
                  ?>


                </div>
              </div>

              <div style="padding-bottom:20px " class="col-md-3 col-sm-6 search-col">
                <div class="input-group-addon search-category-container">

                  <select name='CITY' style='width=100%' id='city' class='dropdown-product picker'>
                    <option value="">Location</option>
                  </select>

                </div>
              </div>

              <div style="padding-bottom:20px" class="col-md-3 col-sm-6 search-col">
                <div class="input-group-addon search-category-container">


                  <?php
                  include_once("DBConnection.php");
                  date_default_timezone_set("Asia/Karachi");
                  $conn = new DBCon();
                  if ($conn->Open()) {
                    $q = "select * from placeholder_grades";
                    $result = $conn->db->query($q);
                    echo "<select name = 'GRADE'  id='grade'  class='dropdown-product picker'>";
                    echo "<option class='subitem' value = ''>Grade</option>";
                    $farray = array();
                    while ($row = mysqli_fetch_array($result)) {
                      echo "<option class='option' value = '" . $row['all_grades'] . "'>" . $row['all_grades'] . "</option selected>";
                      array_push($farray, array($row['all_grades'] => $row['all_grades']));
                    }
                    echo "</select>";
                  }
                  $conn->db->close();
                  ?>

                </div>
              </div>


              <div style="padding-bottom:20px " class="col-md-3 col-sm-6 search-col">
                <div class="input-group-addon search-category-container">

                  <?php
                  include_once("DBConnection.php");
                  date_default_timezone_set("Asia/Karachi");
                  $conn = new DBCon();
                  if ($conn->Open()) {
                    $q = "select * from placeholder_subjects";
                    $result = $conn->db->query($q);
                    echo "<select name = 'SUBJECT'  id='subject'  class='dropdown-product picker'>";
                    echo "<option class='subitem' value = ''>Subject (optional)</option>";
                    $farray = array();
                    while ($row = mysqli_fetch_array($result)) {
                      echo "<option class='option' value = '" . $row['all_subjects'] . "'>" . $row['all_subjects'] . "</option selected>";
                      array_push($farray, array($row['all_subjects'] => $row['all_subjects']));
                    }
                    echo "</select>";
                  }
                  $conn->db->close();
                  ?>
 
                </div>
              </div>


              <div style="padding-bottom:20px" class="col-md-3 col-sm-6 search-col">
                <div class="input-group-addon search-category-container">
                  <?php
                  include_once("DBConnection.php");
                  date_default_timezone_set("Asia/Karachi");
                  $conn = new DBCon();
                  if ($conn->Open()) {
                    $q = "select * from placeholder_prices";
                    $result = $conn->db->query($q);
                    echo "<select name = 'PRICE'  id='price'  class='dropdown-product picker'>";
                    echo "<option value = ''>Fee per subject (optional)</option>";
                    $farray = array();
                    while ($row = mysqli_fetch_array($result)) {
                      echo "<option class='option' value = '" . $row['all_prices'] . "'>" . $row['all_prices'] . "</option selected>";
                      array_push($farray, array($row['all_prices'] => $row['all_prices']));
                    }
                    echo "</select>";
                  }
                  $conn->db->close();
                  ?>
                </div>
              </div>


              <div style="padding-bottom:20px" class="col-md-3 col-sm-6 search-col">
                <div class="input-group-addon search-category-container">
                  <select name='GENDER' style='width=100%' id='gender' class='dropdown-product picker'>
                    <option value="">Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
              </div>


              <div style="padding-bottom:20px; padding-bottom: 20px; padding-bottom:20px" class="col-md-3 col-sm-6 search-col">
                <button class="btn btn-common btn-search" type="submit"> Search </button>
              </div>
            </form>


          </div>

          <!-- End Search box -->
 
        </div>
      </div>
  </section>
  <!-- end intro section -->
  <div class="link-title">
    <a class="link-title-a" href="add_tutor.php"> Add Yourself as Tutor... Click here </a>
  </div>
  <br>
  <br>

  <!-- Counter Section Start -->
  <section id="counter">
    <div class="container">
      <div class="row">

        <div class="col-md-4 col-sm-6 col-xs-12">
          <a class="counter-a" href="all_grades.php">
            <div class="counting wow fadeInDownQuick" data-wow-delay="0s">
              <div class="icon">
                <span>
                  <i class="lnr lnr-license"></i>
                </span>
              </div>
              <div class="desc">
                <h4>Search Tutor by Grade</h4>
              </div>
            </div>
          </a>
        </div>


        <div class="col-md-4 col-sm-6 col-xs-12">
          <a class="counter-a" href="all_subjects.php">
            <div class="counting wow fadeInDownQuick" data-wow-delay="0s">
              <div class="icon">
                <span>
                  <i class="lnr lnr-book"></i>
                </span>
              </div>
              <div class="desc">
                <h4>Search Tutor by Subject</h4>
              </div>
            </div>
          </a>
        </div>
 
        <div class="col-md-4 col-sm-6 col-xs-12">
          <a class="counter-a" href="all_locations.php">
            <div class="counting wow fadeInDownQuick" data-wow-delay="s">
              <div class="icon">
                <span>
                  <i class="lnr lnr-map"></i>
                </span>
              </div>
              <div class="desc">
                <h4>Search Tutor by Location</h4>
              </div>
            </div>
          </a>
        </div>


      </div>
    </div>
  </section>
  <!-- Counter Section End -->

  <br>

  <!-- Advertisement -->
  <?php include_once('add_1.php') ?>
  <br>
  </div>

  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->
 
  <!-- SCRIPT for sidebar .....  by @faheem  -->
  <script>
    /********************************************************* 
		Dependent drop downs code			Coded by: @faheem
		**********************************************************/
    $(document).ready(function() {
      $('#province').on('change', function() {
        var province = $(this).val();
        //  alert(province);
        if (true) {
          $.ajax({
            type: 'POST',
            url: 'http://localhost/tp/load-data-code-1.php',
            //  url: 'http://tutorpedia.com.pk/load-data-code-1.php',
            data: 'province=' + province,
            success: function(html) {

              //       alert(html);
              $('#city').html(html);

            }
          });
        } else {
          $('#state').html('<option value="">Select Province first</option>');
        }
      });

    });
  </script>


</body>

</html>