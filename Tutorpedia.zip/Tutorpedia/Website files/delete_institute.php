<?php
session_start();
date_default_timezone_set("Asia/Karachi");
include("DBConnection.php");
$con = new DBCon();

if ($con->Open()) {

$account = $_SESSION['login_email'];
//  echo $account;


if (isset($_GET['id']) == TRUE) {
$id =  0;
$id = $_GET['id'];
//   echo $id;
}

$query = "delete from institute_info where account='". $account ."' and id='". $id ."'";
$con->db->query($query) or die("deleting error");
echo "<script language = \"javascript\" type = \"text/javascript\"> window.location.href=\"user.php\"; </script>";


$con = null;
}
