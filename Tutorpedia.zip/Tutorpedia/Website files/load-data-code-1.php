<?php 
/****************************************************************************** 
PHP script to handle ajax request for dependant dropdown in 
transformer-current-logs.php file
author: @faheem
*****************************************************************************/
       $province = $_POST['province'];
			include_once("DBConnection.php");
			date_default_timezone_set("Asia/Karachi");
			$con = new DBCon();
			if($con->Open())
			{
			$q = "select * from placeholder_locations where province = '$province'";
			 
			$result = $con->db->query($q); 
			echo "<option value=''>Location</option>";
                $farray = array();
			while($row = mysqli_fetch_array($result) )
			{
				echo "<option value = '".$row['City']."'>".$row['City']."</option selected>";
                array_push($farray,array($row['City']));
                
			}
		
			}
			$con->db->close();
