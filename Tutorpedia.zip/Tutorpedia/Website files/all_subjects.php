<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Links -->
  <?php include_once('links.php') ?>

  <title>Tutorpedia | All Subjects</title>

</head>

<body>
  <!-- Header Section Start -->
  <?php include_once('header.php') ?>
  <!-- Header Section End -->


  <!-- Page Header Start -->
  <div class="header-name">

    Search Tutor by Subject

  </div>
  <!-- Page Header End -->
  <br>
  <!-- Main container Start -->
  <div class="main-container">
    <div class="container">
      <div class="row">
        <div class="col-sm-8">


          <div id="all_subjects" class="all_tutors_tables">
            <h4 class="all_tutor_headers">All Subjects</h4>

            <form action="all_tutor.php" method="POST">
              <div class="frow">
                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=English> English </a>' ?>
                </div>
                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=Urdu> Urdu </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=Mathematics> Mathematics </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=Physics> Physics </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=Chemistry> Chemistry </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=Biology> Biology </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=Islamyath> Islamyath </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=Pakstudy> Pakstudy </a>' ?>
                </div>

                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=Computer Science> Computer&nbsp; Science </a>' ?>
                </div>


                <div class="fcol-45">
                  <?php echo '<a href=search2.php?subjects=Quran Majeed> Quran&nbsp; &nbsp;Majeed </a>' ?>
                </div>

              </div>

          </div>

        </div>

        <!-- Advertisement -->
        <?php include_once('add_2.php') ?>


      </div>
    </div>
  </div>
  <!-- Main container End -->


  <!-- Footer Section Start -->
  <?php include_once('footer.php') ?>
  <!-- Footer Section End -->


</body>

</html>